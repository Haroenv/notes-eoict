<?php
	/**
	 * The first name
	 * @var firstname
	 */
	$firstName = 'Haroen';

	/**
	 * The last name
	 * @var last name
	 */
	$lastName = 'Viaene';

	/**
	 * Print out: 'Hello world',
	 * 'It's raining outside',
	 * 'The value of $firstName is Haroen. The value of $lastName is Viaene'.
	 */
	echo 'Hello World' . PHP_EOL;
	echo 'It\'s raining outside' . PHP_EOL;
	echo 'The value of $firstName is ' . $firstName . '. The value of $lastName is '. $lastName . PHP_EOL;
 ?>